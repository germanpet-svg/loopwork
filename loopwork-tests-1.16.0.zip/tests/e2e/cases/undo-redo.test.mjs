import test from 'node:test';
import assert from 'node:assert/strict';
import { launch } from '../harness.mjs';

let h;
test.before(async () => { h = await launch(); });
test.after(async () => { await h.close(); });

const cat = async (f) => (await h.run(`!cat ${f}`)).split('\n').slice(2).join('\n').trim();
const stateOnDisk = () => h.page.evaluate(async () => {
  const root = await navigator.storage.getDirectory();
  try { const f = await (await root.getDirectoryHandle('.dv')).getFileHandle('undo-state.json'); return JSON.parse(await (await f.getFile()).text()); }
  catch { return null; }
});

test('undo N deshace varios pasos y redo los rehace uno a uno', async () => {
  await h.run('!write m.txt "v1"');
  await h.run('!write m.txt "v2"');
  await h.run('!write m.txt "v3"');
  assert.match(await h.run('!undo --list'), /1\. .*Before write.*m\.txt\n2\. .*Before write.*m\.txt/);
  assert.match(await h.run('!undo 2'), /Undone: «Before write» \(1 item\(s\)\)\.\nUndone: «Before write»/);
  assert.equal(await cat('m.txt'), 'v1');
  assert.match(await h.run('!undo --list'), /2 step\(s\) can be redone/);
  assert.match(await h.run('!redo'), /Redone/);
  assert.equal(await cat('m.txt'), 'v2');
  assert.match(await h.run('!redo'), /Redone/);
  assert.equal(await cat('m.txt'), 'v3');
  assert.match(await h.run('!redo'), /❌ there is nothing to redo/);
});

test('undo repetido retrocede paso a paso y no vuelve a deshacer lo ya deshecho', async () => {
  await h.run('!write s.txt "a"'); await h.run('!write s.txt "b"'); await h.run('!write s.txt "c"');
  await h.run('!undo'); assert.equal(await cat('s.txt'), 'b');
  await h.run('!undo'); assert.equal(await cat('s.txt'), 'a');
  await h.run('!redo 2'); assert.equal(await cat('s.txt'), 'c');
});

test('un cambio nuevo descarta el rehacer', async () => {
  await h.run('!write n.txt "1"'); await h.run('!write n.txt "2"');
  await h.run('!undo');
  assert.equal(await cat('n.txt'), '1');
  await h.run('!write n.txt "otro"');
  assert.match(await h.run('!redo'), /❌ there is nothing to redo/);
  assert.equal(await cat('n.txt'), 'otro');
});

test('se deshace y rehace la creación de un árbol completo', async () => {
  await h.run('!mkdir -p proj/{src,docs}');
  await h.run('!touch proj/src/{a,b}.js proj/docs/x.md');
  await h.run('!write proj/README.md "hola"');
  assert.match(await h.run('!undo'), /Undone: «Create file»/);
  assert.doesNotMatch(await h.run('!ls -R proj'), /README/);
  assert.match(await h.run('!undo'), /Undone: «Create files» \(3 item\(s\)\)/);
  assert.doesNotMatch(await h.run('!tree proj'), /a\.js/);
  assert.match(await h.run('!undo'), /Undone: «Create folders»/);
  assert.match(await h.run('!ls'), /^(?![\s\S]*proj)/);
  assert.match(await h.run('!redo 3'), /Redone: «Create folders»[\s\S]*Redone: «Create files»[\s\S]*Redone: «Create file»/);
  const tree = await h.run('!tree proj');
  assert.match(tree, /a\.js/); assert.match(tree, /x\.md/);
  assert.equal(await cat('proj/README.md'), 'hola');
});

test('deshacer la creación de un archivo conserva su contenido para rehacerlo', async () => {
  await h.run('!write nuevo.txt "contenido valioso"');
  await h.run('!undo');
  assert.match(await h.run('!cat nuevo.txt'), /❌/);
  await h.run('!redo');
  assert.equal(await cat('nuevo.txt'), 'contenido valioso');
});

test('mktree también se deshace de una vez, y una carpeta con contenido nuevo no se borra', async () => {
  await h.run('!mktree arbol "web/\n  css/\n    a.css\n  index.html"');
  await h.run('!write arbol/web/extra.txt "mío"');
  await h.run('!undo');                       // quita extra.txt (creación)
  const out = await h.run('!undo');           // quita el árbol
  assert.match(out, /Undone: «Create tree»/);
  assert.match(await h.run('!ls'), /^(?![\s\S]*arbol)/);
  await h.run('!redo 2');
  assert.match(await h.run('!tree arbol'), /index\.html/);
});

test('undo se niega a borrar una carpeta donde hay archivos ajenos al paso', async () => {
  await h.run('!mkdir -p ajena/sub');
  await h.page.evaluate(async () => {
    const root = await navigator.storage.getDirectory();
    const d = await (await root.getDirectoryHandle('ajena')).getFileHandle('ext.txt', { create: true });
    const w = await d.createWritable(); await w.write('x'); await w.close();
  });
  assert.match(await h.run('!undo'), /❌ undo: folder ajena\/sub|❌ undo: folder ajena is no longer empty/);
  assert.match(await h.run('!ls -R ajena'), /ext\.txt/);
});

test('redo se niega si el archivo cambió después de deshacer', async () => {
  await h.run('!write c.txt "uno"'); await h.run('!write c.txt "dos"');
  await h.run('!undo');
  await h.page.evaluate(async () => {
    const root = await navigator.storage.getDirectory();
    const f = await root.getFileHandle('c.txt'); const w = await f.createWritable(); await w.write('manual'); await w.close();
  });
  assert.match(await h.run('!redo'), /❌ redo: c\.txt changed after the undo/);
});

test('cancelar la confirmación no cambia nada', async () => {
  await h.run('!write k.txt "a"'); await h.run('!write k.txt "b"');
  h.answerDialogs(false);
  assert.match(await h.run('!undo'), /❌ undo cancelled/);
  h.answerDialogs(true);
  assert.equal(await cat('k.txt'), 'b');
});

test('el estado se guarda en disco y sobrevive a recargar la página', async () => {
  await h.run('!write p.txt "x"'); await h.run('!write p.txt "y"');
  await h.run('!undo');
  const before = await stateOnDisk();
  assert.equal(before.redo.at(-1).items[0].path, 'p.txt');
  await h.page.reload();
  await h.page.waitForFunction(() => document.getElementById('dv-host')?.shadowRoot?.querySelector('.input-cmd'));
  assert.match(await h.run('!undo --list'), /can be redone/);
  await h.run('!redo');
  assert.equal(await cat('p.txt'), 'y');
});

test('argumentos no válidos', async () => {
  assert.match(await h.run('!undo 0'), /❌ N must be an integer between 1 and 50/);
  assert.match(await h.run('!undo 1 2'), /❌ usage: undo/);
  assert.match(await h.run('!redo x'), /❌/);
  assert.deepEqual(h.errors, []);
});
