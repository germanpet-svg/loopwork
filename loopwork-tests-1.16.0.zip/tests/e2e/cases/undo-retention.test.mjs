import test from 'node:test';
import assert from 'node:assert/strict';
import { launch } from '../harness.mjs';

let h;
test.before(async () => { h = await launch(); });
test.after(async () => { await h.close(); });

const cat = async (f) => (await h.run(`!cat ${f}`)).split('\n').slice(2).join('\n').trim();
const hashOf = async (f) => (await h.run(`!view ${f}`)).match(/SHA256: ([0-9a-f]{64})/)[1];
const dialog = () => h.page.locator('#dv-code-editor');

test('undo recupera un archivo borrado con rm', async () => {
  await h.run('!write u1.txt "contenido"');
  await h.run('!rm u1.txt');
  assert.doesNotMatch(await h.run('!ls'), /u1\.txt/);
  const out = await h.run('!undo');
  assert.doesNotMatch(out, /❌/);
  assert.equal(await cat('u1.txt'), 'contenido');
});

test('undo tras sobrescribir con write vuelve a la versión anterior (con confirmación)', async () => {
  await h.run('!write u2.txt "uno"');
  await h.run('!write u2.txt "dos"');
  assert.match(await h.run('!undo'), /Undone: «Before write»/);
  assert.match(h.dialogs.at(-1), /Undo 1 step/);
  assert.equal(await cat('u2.txt'), 'uno');
});

test('undo deshace una propuesta multiarchivo completa en un solo paso', async () => {
  await h.run('!write u3a.txt "A"'); await h.run('!write u3b.txt "B"');
  const [a, b] = [await hashOf('u3a.txt'), await hashOf('u3b.txt')];
  await h.run(`!propose '${JSON.stringify({ changes: [
    { path: 'u3a.txt', hash: a, operation: 'replace', old: 'A', new: 'AA' },
    { path: 'u3b.txt', hash: b, operation: 'replace', old: 'B', new: 'BB' }] })}'`);
  await dialog().getByRole('button', { name: 'Apply all' }).click();
  await h.page.waitForTimeout(900);
  assert.equal(await cat('u3a.txt'), 'AA');
  assert.match(await h.run('!undo'), /Undone: .*\(2 item\(s\)\)/);
  assert.equal(await cat('u3a.txt'), 'A'); assert.equal(await cat('u3b.txt'), 'B');
});

test('guardar desde el editor ya crea checkpoint previo', async () => {
  await h.run('!write e1.txt "viejo"');
  await h.run('!replace e1.txt "viejo" "nuevo"');
  await dialog().getByRole('button', { name: /Apply/ }).first().click();
  await h.page.waitForTimeout(900);
  assert.equal(await cat('e1.txt'), 'nuevo');
  assert.match(await h.run('!checkpoint --list --file e1.txt'), /Before saving from the editor/);
  assert.match(h.dialogs.at(-1), /checkpoint/i);
});

test('la retención automática conserva solo 20 copias por archivo', async () => {
  await h.run('!write r.txt "v0"');
  for (let i = 1; i <= 24; i++) await h.run(`!write r.txt "v${i}"`);
  const onDisk = await h.page.evaluate(async () => {
    const root = await navigator.storage.getDirectory();
    const dir = await (await root.getDirectoryHandle('.dv')).getDirectoryHandle('checkpoints');
    let n = 0;
    for await (const [name, handle] of dir.entries()) {
      if (!name.endsWith('.json')) continue;
      if ((JSON.parse(await (await handle.getFile()).text())).path === 'r.txt') n++;
    }
    return n;
  });
  assert.equal(onDisk, 20);
  assert.match(await h.run('!undo'), /Undone: «Before write»/);
});

test('sin errores de página', () => assert.deepEqual(h.errors, []));

test('el listado no rehashea las copias; --verify marca una copia corrupta y restaurar la rechaza', async () => {
  await h.run('!write v.txt "uno"');
  await h.run('!write v.txt "dos"');
  const id = (await h.run('!checkpoint --list --file v.txt')).match(/^([0-9a-f-]{36}) /m)[1];
  await h.page.evaluate(async (cid) => {
    const root = await navigator.storage.getDirectory();
    const dir = await (await root.getDirectoryHandle('.dv')).getDirectoryHandle('checkpoints');
    const f = await dir.getFileHandle(cid + '.bin');
    const size = (await f.getFile()).size;
    const w = await f.createWritable(); await w.write(new Uint8Array(size).fill(88)); await w.close();
  }, id);
  assert.doesNotMatch(await h.run('!checkpoint --list --file v.txt'), /⚠/);
  assert.match(await h.run('!checkpoint --list --file v.txt --verify'), /⚠ checkpoint: (copy hash incorrect|hash de copia incorrecto|.*hash)/i);
  assert.match(await h.run(`!restore ${id}`), /❌/);
});
