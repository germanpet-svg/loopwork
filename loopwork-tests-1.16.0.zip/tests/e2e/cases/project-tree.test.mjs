import test from 'node:test';
import assert from 'node:assert/strict';
import { launch } from '../harness.mjs';

let h;
test.before(async () => { h = await launch(); });
test.after(async () => { await h.close(); });

test('mkdir -p con llaves crea todo el árbol de carpetas y tree lo dibuja', async () => {
  const out = await h.run('!mkdir -p app/{src,docs,tests/unit}');
  assert.match(out, /Folders created \(5\): app, app\/src, app\/docs, app\/tests, app\/tests\/unit/);
  assert.match(await h.run('!touch app/src/{index,util}.js app/docs/guia.md'), /Files created: 3/);
  const tree = await h.run('!tree app');
  assert.match(tree, /app\/\n├── docs\/\n│   └── guia\.md\n├── src\/\n│   ├── index\.js\n│   └── util\.js\n└── tests\/\n    └── unit\/\n\n4 folder\(s\), 3 file\(s\)/);
  assert.match(await h.run('!tree -L 1 app'), /├── docs\/\n├── src\/\n└── tests\/\n\n3 folder\(s\), 0 file\(s\)/);
});

test('sin -p se comporta como bash: falta el padre o ya existe', async () => {
  assert.match(await h.run('!mkdir nuevo/sub'), /❌ folder nuevo does not exist; use mkdir -p/);
  assert.match(await h.run('!mkdir app'), /❌ already exists: app/);
  assert.match(await h.run('!mkdir -p app'), /already existed; nothing was created/);
  assert.match(await h.run('!touch falta/x.txt'), /❌ folder falta does not exist; use touch -p or mkdir -p/);
  assert.match(await h.run('!touch -p falta/x.txt'), /Files created: 1/);
});

test('touch no pisa archivos existentes ni crea sobre carpetas; mkdir no pisa archivos', async () => {
  await h.run('!write dato.txt "hola"');
  assert.match(await h.run('!touch dato.txt'), /Files created: 0\. Already existed: 1/);
  assert.match(await h.run('!cat dato.txt'), /hola/);
  assert.match(await h.run('!touch app'), /❌ is a folder: app/);
  assert.match(await h.run('!mkdir -p dato.txt/x'), /❌ dato\.txt is a file, not a folder/);
});

test('rutas peligrosas o desmesuradas se rechazan', async () => {
  assert.match(await h.run('!mkdir -p .dv/x'), /❌ internal metadata cannot be created/);
  assert.match(await h.run('!mkdir -p ../fuera'), /❌/);
  assert.match(await h.run('!mkdir -p x/{1..500}'), /❌ brace expansion exceeds 200 paths/);
});

test('mktree crea un árbol desde un esquema con sangría y no sobrescribe', async () => {
  const out = await h.run('!mktree web "sitio/\n  css/\n    estilo.css\n  js\n    app.js\n  index.html"');
  assert.match(out, /Created: 4 folder\(s\) and 3 empty file\(s\)/);
  assert.match(await h.run('!tree web'), /sitio\/\n {4}├── css\/|sitio\/\n.*css\//s);
  await h.run('!write web/sitio/index.html "<h1>hola</h1>"');
  const again = await h.run('!mktree web "sitio/\n  index.html\n  nuevo.txt"');
  assert.match(again, /Created: 0 folder\(s\) and 1 empty file\(s\)\. Already existed: 1/);
  assert.match(await h.run('!cat web/sitio/index.html'), /<h1>hola<\/h1>/);
});

test('mktree lee un esquema por pipe y entiende el dibujo de tree', async () => {
  await h.run('!write plan.txt ".\n├── src\n│   └── main.py\n└── README.md"');
  assert.match(await h.run('!cat plan.txt | mktree py'), /Created: 2 folder\(s\) and 2 empty file\(s\)/);
  const tree = await h.run('!tree py');
  assert.match(tree, /README\.md/); assert.match(tree, /main\.py/);
});

test('mktree no toca nada si el esquema choca con lo existente', async () => {
  await h.run('!write choque "x"');
  const out = await h.run('!mktree "choque/\n  a.txt\nlibre.txt"');
  assert.match(out, /❌ choque already exists as a file; nothing is created/);
  assert.doesNotMatch(await h.run('!ls'), /libre\.txt/);
  assert.match(await h.run('!mktree "a\n  b/\n  b"'), /❌ a\/b appears as both a file and a folder/);
  assert.match(await h.run('!mktree ""'), /❌/);
});
