import test from 'node:test';
import assert from 'node:assert/strict';
import { launch } from '../harness.mjs';

let h;
test.before(async () => { h = await launch(); });
test.after(async () => { await h.close(); });

const cat = async (f) => (await h.run(`!cat ${f}`)).split('\n').slice(2).join('\n').trim();

test('cd /datos entra en la carpeta y pwd lo confirma', async () => {
  await h.run('!mkdir -p datos/sub');
  assert.match(await h.run('!pwd'), /^\s*\$ pwd\n\//);
  assert.match(await h.run('!cd /datos'), /\n\/datos$/);
  assert.match(await h.run('!pwd'), /\/datos \$ pwd\n\/datos$/);
});

test('las rutas relativas se resuelven desde la carpeta actual', async () => {
  await h.run('!cd /datos');
  await h.run('!write a.txt "hola"');
  await h.run('!touch sub/b.txt');
  await h.run('!mkdir -p nueva/{x,y}');
  assert.match(await h.run('!ls'), /a\.txt[\s\S]*sub\//);
  assert.equal(await cat('a.txt'), 'hola');
  assert.match(await h.run('!cat /datos/a.txt'), /hola/);
  assert.match(await h.run('!tree'), /nueva\/[\s\S]*x\/[\s\S]*y\//);
  await h.run('!cd /');
  assert.match(await h.run('!ls datos'), /a\.txt/);
  assert.match(await h.run('!cat datos/a.txt'), /hola/);
});

test('cd .. cd - cd sin argumento y rutas con ..', async () => {
  await h.run('!cd /datos/sub');
  assert.match(await h.run('!pwd'), /\/datos\/sub$/);
  assert.match(await h.run('!cd ..'), /\/datos$/);
  assert.match(await h.run('!cd -'), /\/datos\/sub$/);
  assert.match(await h.run('!cat ../a.txt'), /hola/);
  await h.run('!cd');
  assert.match(await h.run('!pwd'), /\/$/);
  assert.match(await h.run('!cd ..'), /\/$/);
});

test('errores: no existe, es un archivo, metadatos internos y fuera del disco', async () => {
  assert.match(await h.run('!cd nada'), /❌ does not exist: nada/);
  assert.match(await h.run('!cd datos/a.txt'), /❌ not a folder: datos\/a\.txt/);
  assert.match(await h.run('!cd .git'), /❌ cd: cannot enter/);
  assert.match(await h.run('!cat ../../x'), /❌ path outside the disk/);
  assert.match(await h.run('!rm -r /'), /❌/);
  assert.match(await h.run('!ls datos'), /a\.txt/); // nada se borró
});

test('redirección, mktree, cp, mv, grep, git add y checkpoint respetan la carpeta actual', async () => {
  await h.run('!cd /datos');
  await h.run('!cat a.txt > copia.txt');
  assert.match(await h.run('!ls'), /copia\.txt/);
  await h.run('!mktree "web/\n  index.html"');
  assert.match(await h.run('!tree web'), /index\.html/);
  await h.run('!cat a.txt | mktree otro'); // esquema "hola" dentro de otro/
  assert.match(await h.run('!ls otro'), /hola/);
  await h.run('!cp a.txt b.txt'); await h.run('!mv b.txt c.txt');
  assert.match(await h.run('!ls'), /c\.txt/);
  assert.match(await h.run('!grep hola a.txt c.txt'), /hola/);
  await h.run('!git init');
  await h.run('!git add a.txt');
  assert.match(await h.run('!git status'), /datos\/a\.txt/);
  assert.match(await h.run('!checkpoint a.txt "prueba"'), /Checkpoint:/);
  assert.match(await h.run('!checkpoint --list --file a.txt'), /datos\/a\.txt/);
});

test('undo y redo funcionan con rutas guardadas aunque estés en otra carpeta', async () => {
  await h.run('!cd /datos');
  await h.run('!write u.txt "uno"'); await h.run('!write u.txt "dos"');
  await h.run('!cd /');
  assert.match(await h.run('!undo'), /Undone/);
  assert.match(await h.run('!cat datos/u.txt'), /uno/);
});

test('la carpeta actual se conserva al recargar y se restablece si se borra', async () => {
  await h.run('!cd /datos/sub');
  await h.page.reload();
  await h.page.waitForFunction(() => document.getElementById('dv-host')?.shadowRoot?.querySelector('.input-cmd'));
  assert.match(await h.run('!pwd'), /\n\/datos\/sub(\n|$)/);
  await h.page.evaluate(async () => {
    const root = await navigator.storage.getDirectory();
    await (await root.getDirectoryHandle('datos')).removeEntry('sub', { recursive: true });
  });
  assert.match(await h.run('!pwd'), /current folder no longer exists[\s\S]*\n\/(\n|$)/);
});

test('el estado del panel muestra la carpeta actual y no hay errores de página', async () => {
  await h.run('!cd /datos');
  const state = await h.page.evaluate(() => document.getElementById('dv-host').shadowRoot.textContent);
  assert.match(state, /\/datos/);
  assert.deepEqual(h.errors, []);
});

test('la lista del panel sigue a cd: carpetas con Entrar, ruta relativa y Subir', async () => {
  const list = () => h.page.evaluate(() => [...document.getElementById('dv-host').shadowRoot.querySelectorAll('#body li')].map((li) => li.innerText.replace(/\s+/g, ' ')).join('\n'));
  const panel = h.page.locator('#dv-host');
  await h.run('!cd /');
  await h.run('!mkdir -p lista/sub'); await h.run('!write lista/uno.txt "1"'); await h.run('!write lista/sub/dos.txt "2"'); await h.run('!write fuera.txt "f"');
  await h.page.waitForTimeout(1500);
  assert.match(await list(), /📁 lista\/[\s\S]*fuera\.txt/);
  await panel.locator('li.folder', { hasText: 'lista/' }).getByRole('button', { name: 'Enter' }).click();
  await h.page.waitForTimeout(1500);
  let rows = await list();
  assert.match(rows, /📂 \/lista/);
  assert.match(rows, /📁 sub\//);
  assert.match(rows, /uno\.txt/);
  assert.doesNotMatch(rows, /fuera\.txt/);
  assert.match(await h.run('!pwd'), /\/lista$/);
  await panel.locator('li.cwd').getByRole('button', { name: 'Up' }).click();
  await h.page.waitForTimeout(1500);
  rows = await list();
  assert.doesNotMatch(rows, /📂/);
  assert.match(rows, /fuera\.txt/);
});
