import test from 'node:test';
import assert from 'node:assert/strict';
import { launch } from '../harness.mjs';

let h;
test.before(async () => { h = await launch(); });
test.beforeEach(async () => { await h.run('!cd /'); });
test.after(async () => { await h.close(); });

const body = async (cmd) => (await h.run(cmd)).replace(/^\n?\S*\s?\$ .*\n/, '').trim();

test('echo con redirección, -e y cat -n', async () => {
  await h.run('!echo hola mundo > saludo.txt');
  assert.equal(await body('!cat saludo.txt'), 'hola mundo');
  await h.run('!echo -e "uno\\ndos" > dos.txt');
  assert.equal(await body('!cat -n dos.txt'), '1  uno\n     2  dos');
  await h.run('!echo mas >> saludo.txt');
  assert.equal(await body('!cat saludo.txt'), 'hola mundo\nmas');
});

test('tail, wc, sort, uniq y tee en pipes', async () => {
  await h.run('!echo -e "b\\na\\nc\\na\\nb\\na" > l.txt');
  assert.equal(await body('!tail -n 2 l.txt'), 'b\na');
  assert.match(await body('!wc -l l.txt'), /^\s*6 l\.txt$/);
  assert.match(await body('!cat l.txt | wc -l'), /^\s*6$/);
  assert.equal(await body('!sort -u l.txt'), 'a\nb\nc');
  assert.equal(await body('!sort -r -u l.txt'), 'c\nb\na');
  assert.match(await body('!sort l.txt | uniq -c'), /3 a\n\s+2 b\n\s+1 c/);
  assert.equal(await body('!cat l.txt | sort -u | tee orden.txt'), 'a\nb\nc');
  assert.equal(await body('!cat orden.txt'), 'a\nb\nc');
});

test('encadenar con ; && y ||', async () => {
  const out = await body('!echo uno ; echo dos');
  assert.equal(out, 'uno\ndos');
  assert.equal(await body('!mkdir -p enc && cd enc && pwd'), 'Folders created (1): enc\n/enc\n/enc');
  await h.run('!cd /');
  assert.match(await body('!cat noexiste.txt && echo no'), /^❌/);
  assert.doesNotMatch(await body('!cat noexiste.txt && echo SALTADO'), /SALTADO/);
  assert.match(await body('!cat noexiste.txt || echo plan-b'), /plan-b$/);
  assert.equal(await body('!true && echo si'), 'si');
  assert.doesNotMatch(await body('!true || echo SALTADO'), /SALTADO/);
  assert.match(await body('!false || echo rescate'), /rescate$/);
});

test('los separadores entre comillas son texto', async () => {
  await h.run('!write q.txt "a;b && c || d"');
  assert.equal(await body('!cat q.txt'), 'a;b && c || d');
});

test('variables: export, $VAR, ${VAR}, env, unset; las no definidas quedan literales', async () => {
  await h.run('!export DIR=proyecto');
  await h.run('!mkdir -p $DIR/src');
  assert.match(await body('!tree ${DIR}'), /src\//);
  assert.match(await body('!env'), /DIR=proyecto/);
  assert.equal(await body('!printenv DIR'), 'proyecto');
  assert.equal(await body('!echo $1 $NOEXISTE'), '$1 $NOEXISTE');
  await h.run('!unset DIR');
  assert.match(await body('!printenv DIR'), /❌ DIR: not set/);
});

test('comodines * y ? en ls, cat, wc, rm y grep', async () => {
  await h.run('!mkdir -p g'); await h.run('!cd g');
  await h.run('!echo uno > a1.txt'); await h.run('!echo dos > a2.txt'); await h.run('!echo tres > b.md'); await h.run('!echo oculto > .secreto');
  assert.equal((await body('!ls a*.txt')).split('\n').length, 2);
  assert.equal(await body('!cat a?.txt'), 'uno\ndos');
  assert.match(await body('!wc -l *.txt'), /a1\.txt[\s\S]*a2\.txt[\s\S]*total/);
  assert.doesNotMatch(await body('!cat *'), /oculto/);
  assert.match(await body('!grep -n tres *.md'), /^1: tres$/);
  assert.match(await body('!grep o *.txt'), /a1\.txt:uno[\s\S]*a2\.txt:dos/);
  assert.match(await body('!cat nada*.x'), /❌ no matches: g\/nada\*\.x/);
  await h.run('!rm a*.txt');
  assert.doesNotMatch(await body('!ls'), /a1\.txt/);
  assert.match(await body('!ls'), /b\.md/);
  await h.run('!cd /');
});

test('grep -r, -l y -c', async () => {
  await h.run('!mkdir -p gr/sub'); await h.run('!echo "hallazgo uno" > gr/a.txt'); await h.run('!echo "nada" > gr/sub/b.txt'); await h.run('!echo "hallazgo dos" > gr/sub/c.txt');
  assert.equal(await body('!grep -r hallazgo gr'), 'gr/a.txt:hallazgo uno\ngr/sub/c.txt:hallazgo dos');
  assert.equal(await body('!grep -rl hallazgo gr'), 'gr/a.txt\ngr/sub/c.txt');
  assert.match(await body('!grep -rc hallazgo gr'), /gr\/a\.txt:1\ngr\/sub\/b\.txt:0\ngr\/sub\/c\.txt:1/);
  assert.match(await body('!grep hallazgo gr'), /❌ gr is a folder; use grep -r/);
});

test('find, stat, rmdir, basename, dirname', async () => {
  await h.run('!mkdir -p fi/a/b'); await h.run('!touch fi/x.js fi/a/y.js fi/a/b/z.md');
  assert.equal(await body('!find fi -name "*.js"'), 'fi/a/y.js\nfi/x.js');
  assert.equal(await body('!find fi -type d'), 'fi\nfi/a\nfi/a/b');
  assert.match(await body('!stat fi/x.js'), /fi\/x\.js: file, 0 B, \d{4}-/);
  assert.match(await body('!stat fi/a'), /fi\/a: folder, 2 item/);
  assert.match(await body('!rmdir fi/a'), /❌ folder fi\/a is not empty/);
  await h.run('!mkdir vacio');
  assert.match(await body('!rmdir vacio'), /Folders removed: vacio/);
  assert.equal(await body('!basename fi/a/y.js .js'), 'y');
  assert.equal(await body('!dirname fi/a/y.js'), 'fi/a');
});

test('cp y mv hacia una carpeta, y rm -rf', async () => {
  await h.run('!write mover.txt "m"'); await h.run('!mkdir dest');
  await h.run('!mv mover.txt dest');
  assert.equal(await body('!cat dest/mover.txt'), 'm');
  await h.run('!cp dest/mover.txt dest/copia.txt');
  assert.equal(await body('!cat dest/copia.txt'), 'm');
  assert.match(await body('!rm -rf dest'), /Deleted: dest/);
  assert.match(await body('!rm -f noexiste.txt'), /^(\(no output\))?$/);
});

test('ls -la, man, which, history, whoami, date y clear', async () => {
  assert.doesNotMatch(await body('!ls -la'), /❌/);
  assert.match(await body('!man grep'), /grep \[-i\].*\n/);
  assert.match(await body('!which cat'), /cat: built-in loopwork command/);
  assert.match(await body('!which nada'), /❌ nada: not found/);
  assert.match(await body('!history'), /echo/);
  assert.equal(await body('!whoami'), 'loopwork');
  assert.match(await body('!date'), /\d{4}/);
  await h.run('!clear');
  const log = await h.page.evaluate(() => document.getElementById('dv-host').shadowRoot.querySelector('#log').innerText);
  assert.ok(log.length < 120, 'el registro quedó casi vacío tras clear');
});

test('los comandos con editor no se pueden encadenar y el undo sigue sirviendo', async () => {
  await h.run('!write z.txt "a"');
  assert.match(await body('!replace z.txt a b ; echo x'), /❌ replace does not accept pipes or redirects|❌ replace/);
  await h.run('!echo nuevo > nuevo.txt');
  assert.deepEqual(h.errors, []);
});
