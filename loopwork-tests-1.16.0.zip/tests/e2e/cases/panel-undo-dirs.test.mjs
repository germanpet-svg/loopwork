import test from 'node:test';
import assert from 'node:assert/strict';
import { launch } from '../harness.mjs';

let h;
test.before(async () => { h = await launch(); });
test.after(async () => { await h.close(); });

const cat = async (f) => (await h.run(`!cat ${f}`)).split('\n').slice(2).join('\n').trim();
const panel = () => h.page.locator('#dv-host');
const logText = () => h.page.evaluate(() => document.getElementById('dv-host').shadowRoot.querySelector('#log').innerText);
const listText = () => h.page.evaluate(() => [...document.getElementById('dv-host').shadowRoot.querySelectorAll('#body li')].map((li) => li.innerText).join('\n'));
const settle = () => h.page.waitForTimeout(1200);

test('los botones Deshacer y Rehacer del panel funcionan y piden confirmación', async () => {
  await h.run('!write b.txt "uno"'); await h.run('!write b.txt "dos"');
  await panel().getByRole('button', { name: 'Undo', exact: true }).click(); await settle();
  assert.equal(await cat('b.txt'), 'uno');
  assert.match(h.dialogs.at(-1), /Undo 1 step/);
  await panel().getByRole('button', { name: 'Redo', exact: true }).click(); await settle();
  assert.equal(await cat('b.txt'), 'dos');
});

test('Alt+Z y Alt+Mayús+Z con el foco en el panel deshacen y rehacen', async () => {
  await h.run('!write z.txt "a"'); await h.run('!write z.txt "b"');
  await panel().locator('.input-cmd').focus();
  await h.page.keyboard.press('Alt+KeyZ'); await settle();
  assert.equal(await cat('z.txt'), 'a');
  await panel().locator('.input-cmd').focus();
  await h.page.keyboard.press('Alt+Shift+KeyZ'); await settle();
  assert.equal(await cat('z.txt'), 'b');
});

test('las carpetas vacías salen en la lista del panel y desaparecen al llenarlas', async () => {
  await h.run('!mkdir -p vacia/interna');
  await settle();
  assert.match(await listText(), /vacia\/interna\/\s*empty folder/);
  await h.run('!touch vacia/interna/x.txt'); await settle();
  assert.doesNotMatch(await listText(), /vacia\/interna\/\s*empty folder/);
});

test('cp, mv e importar archivos nuevos se pueden deshacer como creación', async () => {
  await h.run('!write origen.txt "datos"');
  await h.run('!cp origen.txt copia.txt');
  assert.match(await h.run('!undo'), /Undone: «Create file»/);
  assert.match(await h.run('!cat copia.txt'), /❌/);
  await h.run('!redo');
  assert.equal(await cat('copia.txt'), 'datos');
});

test('ZIP: exportar incluye carpetas vacías y la importación las recrea', async () => {
  await h.run('!mkdir -p zip/carpeta/vacia');
  await h.run('!write zip/dato.txt "x"');
  const bytes = await h.page.evaluate(async () => {
    const created = [];
    const orig = URL.createObjectURL;
    const blobs = [];
    URL.createObjectURL = (b) => { blobs.push(b); return orig.call(URL, b); };
    HTMLAnchorElement.prototype.click = function () { created.push(this.download); };
    const host = document.getElementById('dv-host').shadowRoot;
    [...host.querySelectorAll('button')].find((b) => /Export disk|Exportar disco/.test(b.textContent)).click();
    for (let i = 0; i < 100 && !blobs.length; i++) await new Promise((r) => setTimeout(r, 100));
    return Array.from(new Uint8Array(await blobs[0].arrayBuffer()));
  });
  const text = Buffer.from(bytes).toString('latin1');
  assert.ok(text.includes('zip/carpeta/vacia/'), 'el ZIP debe traer la carpeta vacía');
  assert.ok(text.includes('zip/dato.txt'));
  // Se borra y se reimporta
  await h.run('!rm zip/dato.txt');
  await h.page.evaluate(async () => {
    const root = await navigator.storage.getDirectory();
    await root.removeEntry('zip', { recursive: true });
  });
  const input = panel().locator('input[type=file][accept*=zip]');
  await input.setInputFiles({ name: 'b.zip', mimeType: 'application/zip', buffer: Buffer.from(bytes) });
  await settle(); await settle();
  assert.match(await h.run('!tree zip'), /carpeta\/\n.*vacia\//s);
  assert.equal(await cat('zip/dato.txt'), 'x');
  assert.match(await logText(), /1 empty folder\(s\) created|empty folder\(s\) created/);
});

test('sin errores de página', () => assert.deepEqual(h.errors, []));
