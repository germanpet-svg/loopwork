// Análisis de llaves, `;` en CSS, sangría de Python y localización de funciones (módulo puro entre marcas <codetools>).
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const src = fs.readFileSync(path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..', 'loopwork.js'), 'utf8');
const T = new Function(src.slice(src.indexOf('// <codetools>'), src.indexOf('// </codetools>')) +
  ';return {codeExpandBraces,codeParseTreeSpec,codeBlocks,codeAnalyze,codeApplyFixes,codeFunctions,codeFunctionAt,codeReplaceFunction}')();
const types = (text, lang) => T.codeAnalyze(text, lang).problems.map((p) => `${p.type}@${p.line}`);
const fix = (text, lang) => T.codeApplyFixes(text, T.codeAnalyze(text, lang).problems);

test('JS: llave sin cerrar al final y arreglo', () => {
  const text = 'function a(){\n  if (x) {\n    b();\n  }\n';
  assert.deepEqual(types(text, 'js'), ['unclosed@1']);
  assert.equal(fix(text, 'js'), text + '\n}');
});

test('JS: cadenas, comentarios, regex y plantillas no cuentan como llaves', () => {
  const text = "const s = '}{'; // }\nconst r = /[}]/.test(s);\nconst t = `a${ {x: 1}.x }}`;\n/* { */\n";
  assert.deepEqual(types(text, 'js'), []);
});

test('JS: cierre equivocado se corrige y cierre que falta en medio se inserta', () => {
  assert.equal(fix('foo(1, 2];\n', 'js'), 'foo(1, 2);\n');
  assert.equal(fix('function a(){ if(x){ y(1 }\n}\n', 'js'), 'function a(){ if(x){ y(1) }\n}\n');
  assert.deepEqual(types('x = 1 }\n', 'js'), ['extra@1']);
});

test('JS: cadena sin cerrar se avisa pero no hay arreglo automático', () => {
  const r = T.codeAnalyze("const a = 'hola;\nconst b = 1;\n", 'js');
  assert.equal(r.problems[0].type, 'unterminated-string');
  assert.equal(r.problems[0].fix, null);
});

test('CSS: falta ; entre declaraciones (error) y en la última (estilo); selectores no se confunden', () => {
  const css = 'a:hover\n{\n  color: red\n  background: blue;\n  margin: 0\n}\nb { content: "}" }\n';
  const r = T.codeAnalyze(css, 'css').problems;
  assert.deepEqual(r.map((p) => [p.type, p.kind, p.line]), [['semicolon', 'error', 3], ['semicolon-last', 'style', 5]]);
  assert.equal(fix(css, 'css'), 'a:hover\n{\n  color: red;\n  background: blue;\n  margin: 0;\n}\nb { content: "}" }\n');
});

test('CSS: llave sin cerrar', () => assert.deepEqual(types('a { color: red;\n', 'css'), ['unclosed@1']));

test('HTML: revisa solo el contenido de <script> y <style>', () => {
  const html = '<p>{ ( [</p>\n<style>\na {\n  color: red\n  margin: 0; }\n</style>\n<script>\nfunction f() {\n</script>\n<script type="application/json">{ "a": [</script>';
  assert.deepEqual(types(html, 'html'), ['semicolon@4', 'unclosed@8']);
});

test('Python: dos puntos, sangría inesperada, no coincidente y bloque esperado', () => {
  assert.deepEqual(types('def f(x)\n    return x\n', 'py'), ['missing-colon@1']);
  assert.equal(fix('def f(x)  # c\n    return x\n', 'py'), 'def f(x):  # c\n    return x\n');
  assert.deepEqual(types('x = 1\n    y = 2\n', 'py'), ['unexpected-indent@2']);
  assert.deepEqual(types('if a:\n    if b:\n        c\n  d\n', 'py'), ['unindent-mismatch@4']);
  assert.deepEqual(types('if a:\nb = 1\n', 'py'), ['expected-indent@2']);
  assert.deepEqual(types('def f(a,\n      b):\n    s = """\nx\n"""\n    return (a +\nb)\n', 'py'), []);
});

test('Python: tabuladores mezclados con espacios', () => {
  const text = 'if a:\n\t    b = 1\n';
  assert.equal(types(text, 'py')[0], 'mixed-indent@2');
  assert.equal(fix(text, 'py'), 'if a:\n        b = 1\n');
});

const JS = 'class A {\n  render() {\n    return 1;\n  }\n  other() { return 2; }\n}\nfunction render() {\n  return `x${1}`;\n}\nconst f = (a) => a + 1;\nconst g = async function () {\n  return 3;\n};\nconst o = { k: function (z) { return z; } };\n';

test('JS: lista funciones, métodos, flechas y clases con su propietario', () => {
  const list = T.codeFunctions(JS, 'js').map((f) => `${f.qname}:${f.kind}:${f.line}-${f.endLine}`);
  assert.deepEqual(list, ['A:class:1-6', 'A.render:method:2-4', 'A.other:method:5-5', 'render:function:7-9', 'f:function:10-10', 'g:function:11-13', 'k:function:14-14']);
});

test('seleccionar función: la más pequeña y luego la exterior', () => {
  const list = T.codeFunctions(JS, 'js');
  const at = JS.indexOf('return 1');
  const inner = T.codeFunctionAt(list, at, at);
  assert.equal(inner.qname, 'A.render');
  const outer = T.codeFunctionAt(list, inner.start, inner.end);
  assert.equal(outer.qname, 'A');
  assert.equal(T.codeFunctionAt(list, JS.indexOf('const f'), JS.indexOf('const f')).qname, 'f');
});

test('reemplazar función: respeta nombre exacto, sangría y CRLF', () => {
  const r = T.codeReplaceFunction(JS, 'js', 'A.render', 'render() {\n  return 99;\n}');
  assert.ok(r.candidate.includes('class A {\n  render() {\n    return 99;\n  }\n  other()'));
  const crlf = T.codeReplaceFunction(JS.replace(/\n/g, '\r\n'), 'js', 'f', 'const f = (a) => a * 2;');
  assert.ok(crlf.candidate.includes('const f = (a) => a * 2;\r\nconst g'));
  assert.equal(T.codeReplaceFunction(JS, 'js', 'nada', 'x').error, 'notfound');
});

test('reemplazar función: nombre ambiguo se rechaza', () => {
  const dup = 'class A {\n  go() { return 1; }\n}\nclass B {\n  go() { return 2; }\n}\n';
  assert.equal(T.codeReplaceFunction(dup, 'js', 'go', 'go() { return 3; }').error, 'ambiguous');
  assert.ok(T.codeReplaceFunction(dup, 'js', 'B.go', 'go() { return 3; }').candidate.includes('  go() { return 3; }\n}\n'));
});

const PY = 'import os\n\n@deco\ndef a(x):\n    """doc\n    more\n"""\n    return x\n\nclass B:\n    def m(self):\n        pass\n\n    def n(self):\n        return 1\n\nprint(1)\n';

test('Python: funciones con decoradores, docstrings multilínea y métodos', () => {
  const list = T.codeFunctions(PY, 'py').map((f) => `${f.qname}:${f.kind}:${f.line}-${f.endLine}`);
  assert.deepEqual(list, ['a:function:3-8', 'B:class:10-15', 'B.m:function:11-12', 'B.n:function:14-15']);
});

test('Python: reemplazar un método reajusta la sangría del bloque pegado', () => {
  const r = T.codeReplaceFunction(PY, 'py', 'B.m', 'def m(self):\n    return 5');
  assert.ok(r.candidate.includes('class B:\n    def m(self):\n        return 5\n\n    def n(self):'));
});

test('HTML: funciones dentro de <script>', () => {
  const html = '<html>\n<script>\n  function hi() {\n    return 1;\n  }\n</script>\n</html>\n';
  const r = T.codeReplaceFunction(html, 'html', 'hi', 'function hi() {\n  return 2;\n}');
  assert.equal(r.candidate, '<html>\n<script>\n  function hi() {\n    return 2;\n  }\n</script>\n</html>\n');
});

const blocks = (text, lang) => T.codeBlocks(text, lang).map((b) => `${b.kind}:${b.startLine}-${b.endLine}@${b.depth}`);

test('guías: llaves anidadas con su profundidad; los bloques de una sola línea no cuentan', () => {
  const js = 'function a() {\n  if (x) {\n    y();\n  } else {\n    z();\n  }\n  const o = { k: 1 };\n}\n';
  assert.deepEqual(blocks(js, 'js'), ['brace:1-8@0', 'brace:2-4@1', 'brace:4-6@1']);
});

test('guías: arrays multilínea, CSS y llaves dentro de cadenas', () => {
  assert.deepEqual(blocks("const a = [\n  '}',\n  2\n];\n", 'js'), ['bracket:1-4@0']);
  assert.deepEqual(blocks('a {\n  color: red;\n}\n@media x {\n  b {\n    c: d;\n  }\n}\n', 'css'), ['brace:1-3@0', 'brace:4-8@0', 'brace:5-7@1']);
});

test('guías: Python por sangría, con firma en varias líneas y docstring', () => {
  const py = 'class B:\n    def m(self,\n          a):\n        \"\"\"doc\n  x\n        \"\"\"\n        return a\n\n    def n(self):\n        pass\nprint(1)\n';
  assert.deepEqual(blocks(py, 'py'), ['indent:1-10@0', 'indent:2-7@1', 'indent:9-10@1']);
});

test('guías: HTML con etiquetas multilínea y el contenido de <script>', () => {
  const html = '<div>\n  <p>hola</p>\n  <ul>\n    <li>a</li>\n  </ul>\n</div>\n<script>\nfunction f() {\n  return 1;\n}\n</script>\n';
  assert.deepEqual(blocks(html, 'html'), ['tag:1-6@0', 'tag:3-5@1', 'brace:8-10@0']);
});

test('llaves tipo bash: listas, anidadas, rangos numéricos y de letras, y literales', () => {
  const x = (s) => T.codeExpandBraces(s);
  assert.deepEqual(x('app/{src,docs}'), ['app/src', 'app/docs']);
  assert.deepEqual(x('a{b,c}d{1,2}'), ['abd1', 'abd2', 'acd1', 'acd2']);
  assert.deepEqual(x('p/{a,b/{c,d}}'), ['p/a', 'p/b/c', 'p/b/d']);
  assert.deepEqual(x('f{1..3}.txt'), ['f1.txt', 'f2.txt', 'f3.txt']);
  assert.deepEqual(x('f{08..10}'), ['f08', 'f09', 'f10']);
  assert.deepEqual(x('{c..a}'), ['c', 'b', 'a']);
  assert.deepEqual(x('sin{llaves}'), ['sin{llaves}']);
  assert.deepEqual(x('{a,b}{}'), ['a{}', 'b{}']);
});

test('llaves: se rechaza una expansión desmesurada', () => {
  assert.throws(() => T.codeExpandBraces('{1..500}'), { code: 'brace-limit' });
  assert.throws(() => T.codeExpandBraces('{a,b,c,d,e,f,g,h,i,j}{a,b,c,d,e,f,g,h,i,j}{a,b,c,d,e,f,g,h,i,j}'), { code: 'brace-limit' });
});

const spec = (s) => T.codeParseTreeSpec(s).map((e) => `${e.path.join('/')}${e.dir ? '/' : ''}`);

test('esquema de árbol: sangría, carpetas con / o con hijos, comentarios', () => {
  assert.deepEqual(spec('proyecto/\n  src/\n    index.js\n    util.js\n  docs\n    guia.md   # texto\n  README.md\n# nota\n'),
    ['proyecto/', 'proyecto/src/', 'proyecto/src/index.js', 'proyecto/src/util.js', 'proyecto/docs/', 'proyecto/docs/guia.md', 'proyecto/README.md']);
});

test('esquema de árbol: dibujo de `tree` con ├── └── │ y línea final de resumen', () => {
  const drawing = '.\n├── src\n│   ├── a.js\n│   └── b.js\n└── README.md\n\n1 directory, 3 files\n';
  assert.deepEqual(spec(drawing), ['src/', 'src/a.js', 'src/b.js', 'README.md']);
});

test('esquema de árbol: rutas con / dentro de un nombre y límite de elementos', () => {
  assert.deepEqual(spec('app\n  src/lib/x.js'), ['app/', 'app/src/lib/x.js']);
  assert.throws(() => T.codeParseTreeSpec(Array.from({ length: 400 }, (_, i) => `f${i}`).join('\n')), { code: 'tree-limit' });
});
