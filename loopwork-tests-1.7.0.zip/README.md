# Pruebas de loopwork

```bash
cd tests/e2e
npm install            # playwright, isomorphic-git@1.32.1, diff@7.0.0
npx playwright install chromium   # o CHROMIUM_PATH=/ruta/a/chromium
npm test               # unitarias (i18n) + e2e
npm run test:unit      # solo cobertura de traducciones, sin navegador
```

- `../unit/i18n-coverage.test.mjs`: todo texto de `t()` debe tener traducción en/zh-CN y conservar `{n}`.
- `cases/*.test.mjs`: Chromium real. El arnés (`harness.mjs`) sirve una copia de `loopwork.js` con el shadow DOM
  abierto, ejecuta comandos en el panel y, con `origin: 'https://claude.ai/'`, sirve la página de prueba bajo
  ese host para ejercitar el adaptador de cada sitio.
- `LOOPWORK_JS=/ruta/otro.js npm test` prueba otra copia del script (útil para comprobar que una prueba falla sin el arreglo).
