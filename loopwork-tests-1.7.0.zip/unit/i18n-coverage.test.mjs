// Cada texto pasado a t() debe tener traducción en I18N/EXTRA_I18N (en y zh-CN).
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const src = fs.readFileSync(path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..', 'loopwork.js'), 'utf8');

function scanTemplate(i) {
  let out = '', n = 0;
  while (i < src.length) {
    const c = src[i];
    if (c === '\\') { out += src.slice(i, i + 2); i += 2; continue; }
    if (c === '`') return [out, i + 1];
    if (c === '$' && src[i + 1] === '{') {
      out += `{${n++}}`; i += 2;
      let depth = 1;
      while (depth) {
        const d = src[i];
        if (d === '{') { depth++; i++; }
        else if (d === '}') { depth--; i++; }
        else if (d === '`') [, i] = scanTemplate(i + 1);
        else if (d === "'" || d === '"') { i++; while (src[i] !== d) { if (src[i] === '\\') i++; i++; } i++; }
        else i++;
      }
      continue;
    }
    out += c; i++;
  }
  throw new Error('plantilla sin cerrar');
}

const cook = (k) => new Function('return `' + k.replace(/`/g, '\\`') + '`')();
const keys = new Set();
for (const m of src.matchAll(/(?<![\w$.])t`/g)) keys.add(cook(scanTemplate(m.index + m[0].length)[0]));
for (const m of src.matchAll(/(?<![\w$.])t\((['"])((?:\\.|(?!\1).)*)\1\s*[,)]/g)) keys.add(cook(m[2]));

const start = src.indexOf('const I18N'), end = src.indexOf('  const missingTranslations');
const catalogs = new Function(src.slice(start, end).replace(/const I18N/, 'var I18N').replace(/const EXTRA_I18N/, 'var EXTRA_I18N')
  .replace(/function t[\s\S]*$/, '') + ';return {I18N,EXTRA_I18N}')();
const all = { ...catalogs.I18N, ...catalogs.EXTRA_I18N };

test('hay textos que comprobar', () => assert.ok(keys.size > 500));

test('todos los textos de t() tienen traducción a en y zh-CN', () => {
  const missing = [...keys].filter((k) => !Object.hasOwn(all, k));
  assert.deepEqual(missing, [], `Sin traducción:\n${missing.join('\n')}`);
});

test('las traducciones conservan los marcadores {n}', () => {
  const bad = [];
  for (const [k, v] of Object.entries(all)) {
    const marks = (s) => [...String(s).matchAll(/\{\d+\}/g)].map((m) => m[0]).sort().join();
    if (!Array.isArray(v) || v.length < 2) { bad.push(k); continue; }
    if (marks(k) !== marks(v[0]) || marks(k) !== marks(v[1])) bad.push(k);
  }
  assert.deepEqual(bad.slice(0, 10), [], 'marcadores distintos entre original y traducción');
});
