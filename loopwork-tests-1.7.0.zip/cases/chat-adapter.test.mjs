import test from 'node:test';
import assert from 'node:assert/strict';
import { launch } from '../harness.mjs';

// Composer estilo claude.ai (contenteditable ProseMirror) con botón de envío localizado y el panel de loopwork.
const CLAUDE_PAGE = `<!doctype html><meta charset="utf-8"><title>Claude (test)</title>
<body><main><div data-testid="user-message">hola</div></main>
<fieldset><div class="ProseMirror" contenteditable="true" role="textbox"><p><br></p></div>
<button aria-label="Adjuntar archivo">+</button>
<button aria-label="Enviar mensaje" id="send">↑</button></fieldset>
<script>
  // Hostil: un manejador global de pegado del sitio que cancela el evento.
  document.addEventListener('paste', (e) => { window.__sitePaste = (window.__sitePaste || 0) + 1; e.preventDefault(); });
</script>
<script src="isomorphic-git.umd.min.js"></script><script src="diff.min.js"></script><script src="app.js"></script></body>`;

let h;
test.before(async () => { h = await launch({ pageHtml: CLAUDE_PAGE, origin: 'https://claude.ai/' }); });
test.after(async () => { await h.close(); });

test('diag detecta composer, botón de envío localizado y sitio Claude', async () => {
  const out = await h.run('!diag');
  assert.match(out, /sitio: Claude \(claude\.ai\)/);
  assert.match(out, /entrada de chat: div contenteditable/);
  assert.match(out, /botón enviar: button aria-label="Enviar mensaje"/);
  assert.match(out, /mensajes usuario \/ asistente: 1 \/ 0/);
  assert.match(out, /traducciones que faltan: ninguna/);
});

test('diag no incluye el texto del chat ni de los archivos', async () => {
  await h.page.evaluate(() => { document.querySelector('.ProseMirror').textContent = 'SECRETO-DEL-CHAT'; });
  await h.run('!write s.txt "SECRETO-DEL-ARCHIVO"');
  const out = await h.run('!diag');
  assert.doesNotMatch(out, /SECRETO/);
});

test('el pegado en el panel no llega al manejador global del sitio', async () => {
  const result = await h.page.evaluate(() => {
    const ta = document.getElementById('dv-host').shadowRoot.querySelector('.input-cmd');
    ta.focus();
    const dt = new DataTransfer(); dt.setData('text/plain', 'pegado');
    const ev = new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true, composed: true });
    ta.dispatchEvent(ev);
    return { prevented: ev.defaultPrevented, site: window.__sitePaste || 0 };
  });
  assert.equal(result.site, 0, 'el manejador del sitio no debe ver el evento');
  assert.equal(result.prevented, false, 'el pegado nativo no debe cancelarse');
});

test('sin errores de página', () => assert.deepEqual(h.errors, []));
