import test from 'node:test';
import assert from 'node:assert/strict';
import { launch } from '../harness.mjs';

const PAGE = `<!doctype html><meta charset="utf-8"><title>Claude (test)</title>
<body><fieldset><div class="ProseMirror" contenteditable="true" role="textbox"><p><br></p></div>
<button aria-label="Enviar mensaje" id="send">↑</button></fieldset>
<script>
  window.__sent = [];
  document.getElementById('send').addEventListener('click', () => {
    const box = document.querySelector('.ProseMirror');
    window.__sent.push(box.innerText); box.innerHTML = '<p><br></p>';
  });
</script>
<script src="isomorphic-git.umd.min.js"></script><script src="diff.min.js"></script><script src="app.js"></script></body>`;

let h;
test.before(async () => { h = await launch({ pageHtml: PAGE, origin: 'https://claude.ai/' }); });
test.after(async () => { await h.close(); });

const root = () => h.page.locator('#dv-host');
async function openTaskDialog() {
  await root().getByRole('button', { name: 'Share with instruction...' }).click();
  await h.page.waitForTimeout(300);
}

test('envía tarea + árbol + varios archivos con hash y las reglas de changes', async () => {
  await h.run('!write uno.txt "primero"');
  await h.run('!write dos.txt "segundo"');
  await openTaskDialog();
  await root().locator('input[type=checkbox][value="uno.txt"]').check();
  await root().locator('input[type=checkbox][value="dos.txt"]').check();
  await root().locator('#dv-task-tree').check();
  await root().getByLabel('Instruction for the AI').fill('Cambia primero por 1');
  await root().getByRole('button', { name: 'Review and send' }).click();
  await h.page.waitForFunction(() => window.__sent.length === 1, null, { timeout: 8000 });
  const msg = await h.page.evaluate(() => window.__sent[0]);
  assert.match(msg, /\[Task\]\s+Cambia primero por 1/);
  assert.match(msg, /\[Disk tree\]/);
  assert.match(msg, /uno\.txt/); assert.match(msg, /dos\.txt/);
  assert.equal((msg.match(/SHA256: [0-9a-f]{64}/g) || []).length, 2);
  assert.match(msg, /"changes"/);
  assert.match(h.dialogs.at(-1), /Share with the chat|characters/i);
});

test('rechaza sin instrucción, sin archivos o con más de 64 KB', async () => {
  await openTaskDialog();
  await root().getByLabel('Instruction for the AI').fill('');
  await root().locator('input[type=checkbox][value="uno.txt"]').check();
  await root().getByRole('button', { name: 'Review and send' }).click();
  await h.page.waitForTimeout(400);
  assert.match(await h.page.evaluate(() => document.getElementById('dv-host').shadowRoot.querySelector('#log').innerText), /write what you want to change/);
  assert.equal(await h.page.evaluate(() => window.__sent.length), 1);
});

test('sin errores de página', () => assert.deepEqual(h.errors, []));
