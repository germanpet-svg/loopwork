import test from 'node:test';
import assert from 'node:assert/strict';
import { launch } from '../harness.mjs';

let h;
test.before(async () => { h = await launch(); });
test.after(async () => { await h.close(); });

const state = () => h.page.evaluate(() => {
  const root = document.getElementById('dv-code-editor')?.shadowRoot;
  if (!root) return null;
  const live = root.querySelector('.live');
  return { display: live.style.display, srcdoc: (live.querySelector('iframe').srcdoc || '').length, pressed: root.querySelector('button[aria-label="Live preview"]').getAttribute('aria-pressed') };
});

test('un HTML se abre con la vista previa visible y el botón la oculta', async () => {
  await h.run('!write v.html "<h1>hola</h1>"');
  await h.run('!edit v.html');
  assert.equal((await state()).pressed, 'true');
  assert.notEqual((await state()).display, 'none');
  await h.page.locator('#dv-code-editor').locator('button[aria-label="Live preview"]').click();
  assert.equal((await state()).pressed, 'false');
  assert.equal((await state()).display, 'none');
});

test('ocultar la vista previa se recuerda y volver a pulsar la muestra con contenido', async () => {
  const ed = h.page.locator('#dv-code-editor');
  await ed.getByRole('button', { name: 'Close' }).first().click();
  await h.page.waitForTimeout(200);
  await h.run('!edit v.html');
  assert.equal((await state()).pressed, 'false');
  await ed.locator('button[aria-label="Live preview"]').click();
  await h.page.waitForTimeout(500);
  const s = await state();
  assert.equal(s.pressed, 'true');
  assert.ok(s.srcdoc > 0, 'el iframe debe tener contenido');
});

test('abrir, cerrar y reabrir varias veces siempre muestra la vista previa con contenido', async () => {
  const ed = h.page.locator('#dv-code-editor');
  for (let i = 0; i < 3; i++) {
    await ed.getByRole('button', { name: 'Close' }).first().click();
    await h.page.waitForTimeout(200);
    await h.run('!edit v.html');
    await h.page.waitForTimeout(400);
    const s = await state();
    assert.equal(s.pressed, 'true');
    assert.ok(s.srcdoc > 0);
  }
});

test('pulsar la vista previa muchas veces siempre vuelve a cargar el contenido', async () => {
  const ed = h.page.locator('#dv-code-editor');
  await ed.getByRole('button', { name: 'Close' }).first().click();
  await h.page.waitForTimeout(200);
  await h.run('!edit v.html');
  const button = ed.locator('button[aria-label="Live preview"]');
  for (let i = 0; i < 6; i++) {
    await button.click();
    await h.page.waitForTimeout(450);
    const s = await state();
    const shown = s.pressed === 'true';
    assert.equal(s.display === 'none', !shown);
    if (shown) assert.ok(s.srcdoc > 0, `ciclo ${i}: el iframe debe tener contenido`);
    else assert.equal(s.srcdoc, 0, `ciclo ${i}: oculto debe estar vacío`);
  }
});

test('sin errores de página', () => assert.deepEqual(h.errors, []));
