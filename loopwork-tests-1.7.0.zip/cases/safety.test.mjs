import test from 'node:test';
import assert from 'node:assert/strict';
import { launch } from '../harness.mjs';

let h;
test.before(async () => { h = await launch(); });
test.after(async () => { await h.close(); });

const checkpoints = async () => h.run('!checkpoint --list');

test('rm guarda una copia previa recuperable y lo avisa en la confirmación', async () => {
  await h.run('!write f1.txt "hola"');
  const out = await h.run('!rm f1.txt');
  assert.match(out, /Deleted: f1\.txt/);
  assert.match(h.dialogs.at(-1), /checkpoint/i);
  assert.match(await checkpoints(), /f1\.txt.*Before rm/);
  const id = (await checkpoints()).match(/^([0-9a-f-]{36}) \| "f1\.txt"/m)[1];
  const restored = await h.run(`!restore ${id}`);
  assert.doesNotMatch(restored, /❌/);
});

test('cancelar la confirmación no borra ni crea copia', async () => {
  await h.run('!write f2.txt "x"');
  h.answerDialogs(false);
  const out = await h.run('!rm f2.txt');
  h.answerDialogs(true);
  assert.match(out, /❌/);
  assert.match(await h.run('!ls'), /f2\.txt/);
  assert.doesNotMatch(await checkpoints(), /f2\.txt/);
});

test('write sobre un archivo existente con contenido distinto crea copia; con el mismo contenido no', async () => {
  await h.run('!write f3.txt "uno"');
  await h.run('!write f3.txt "uno"');
  assert.doesNotMatch(await checkpoints(), /f3\.txt/);
  await h.run('!write f3.txt "dos"');
  assert.match(await checkpoints(), /f3\.txt.*Before write/);
});

test('cp/mv que reemplaza un destino guarda copia del destino', async () => {
  await h.run('!write src.txt "nuevo"');
  await h.run('!write dst.txt "viejo"');
  const out = await h.run('!cp src.txt dst.txt');
  assert.doesNotMatch(out, /❌/);
  assert.match(await checkpoints(), /dst\.txt.*Before cp/);
});

test('archivos mayores que el límite avisan de que no tendrán copia', async () => {
  await h.page.evaluate(async () => {
    const root = await navigator.storage.getDirectory();
    const fh = await root.getFileHandle('big.bin', { create: true });
    const w = await fh.createWritable(); await w.write(new Uint8Array(1.5 * 1024 * 1024)); await w.close();
  });
  await h.run('!rm big.bin');
  assert.match(h.dialogs.at(-1), /NOT have a copy/);
});

test('Eliminar todos (rm -r) incluye copias de los archivos de una carpeta', async () => {
  await h.run('!write dir/a.txt "a"');
  await h.run('!write dir/b.txt "b"');
  const out = await h.run('!rm -r dir');
  assert.match(out, /Safety copies: 2/);
});

test('sin errores de página', () => assert.deepEqual(h.errors, []));
