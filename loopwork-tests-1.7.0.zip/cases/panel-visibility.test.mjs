import test from 'node:test';
import assert from 'node:assert/strict';
import { launch } from '../harness.mjs';

let h;
test.before(async () => { h = await launch(); });
test.after(async () => { await h.close(); });

const view = () => h.page.evaluate(() => {
  const r = document.getElementById('dv-host').shadowRoot;
  const vis = (el) => getComputedStyle(el).display !== 'none';
  return { panel: vis(r.querySelector('#panel')), launcher: vis(r.querySelector('#launcher')) };
});
const click = (sel) => h.page.evaluate((s) => document.getElementById('dv-host').shadowRoot.querySelector(s).click(), sel);

test('la X oculta el panel y el logo flotante lo vuelve a mostrar', async () => {
  assert.deepEqual(await view(), { panel: true, launcher: false });
  await click('button[aria-label="Hide panel"]');
  assert.deepEqual(await view(), { panel: false, launcher: true });
  await click('#launcher');
  assert.deepEqual(await view(), { panel: true, launcher: false });
});

test('el evento loopwork:toggle (icono de la extensión) y Alt+Shift+D alternan el panel', async () => {
  await h.page.evaluate(() => window.dispatchEvent(new CustomEvent('loopwork:toggle')));
  assert.equal((await view()).panel, false);
  await h.page.keyboard.press('Alt+Shift+KeyD');
  assert.equal((await view()).panel, true);
});

test('lo oculto se recuerda al recargar la página', async () => {
  await click('button[aria-label="Hide panel"]');
  await h.page.reload();
  await h.page.waitForFunction(() => document.getElementById('dv-host')?.shadowRoot?.querySelector('#launcher'));
  assert.deepEqual(await view(), { panel: false, launcher: true });
  await click('#launcher');
});

test('el comando sigue funcionando tras ocultar y mostrar', async () => {
  await click('button[aria-label="Hide panel"]'); await click('#launcher');
  assert.match(await h.run('!write z.txt "ok"'), /Tx OK/);
});

test('sin errores de página', () => assert.deepEqual(h.errors, []));
