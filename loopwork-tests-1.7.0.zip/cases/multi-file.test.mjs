import test from 'node:test';
import assert from 'node:assert/strict';
import { launch } from '../harness.mjs';

let h;
test.before(async () => { h = await launch(); });
test.after(async () => { await h.close(); });

const hashOf = async (file) => (await h.run(`!view ${file}`)).match(/SHA256: ([0-9a-f]{64})/)[1];
const cat = async (file) => (await h.run(`!cat ${file}`)).split('\n').slice(2).join('\n').trim();
const dialog = () => h.page.locator('#dv-code-editor');
const proposal = (changes) => `!propose '${JSON.stringify({ changes })}'`;

async function setup(tag) {
  await h.run(`!write ${tag}a.txt "uno"`);
  await h.run(`!write ${tag}b.txt "dos"`);
  return { a: await hashOf(`${tag}a.txt`), b: await hashOf(`${tag}b.txt`) };
}

test('aplica dos archivos tras una sola revisión y crea un checkpoint por archivo', async () => {
  const x = await setup('m1');
  const out = await h.run(proposal([
    { path: 'm1a.txt', hash: x.a, operation: 'replace', old: 'uno', new: 'UNO' },
    { path: 'm1b.txt', hash: x.b, operation: 'append', new: '+' }]));
  assert.match(out, /Proposal prepared/);
  await dialog().getByRole('button', { name: 'Apply all' }).click();
  await h.page.waitForTimeout(800);
  assert.equal(await dialog().count(), 0);
  assert.equal(await cat('m1a.txt'), 'UNO');
  assert.equal(await cat('m1b.txt'), 'dos+');
  const cps = await h.run('!checkpoint --list --tag "Before multi-file proposal"');
  assert.match(cps, /m1a\.txt/); assert.match(cps, /m1b\.txt/);
});

test('cancelar no escribe nada', async () => {
  const x = await setup('m2');
  await h.run(proposal([
    { path: 'm2a.txt', hash: x.a, operation: 'replace', old: 'uno', new: 'X' },
    { path: 'm2b.txt', hash: x.b, operation: 'replace', old: 'dos', new: 'Y' }]));
  await dialog().getByRole('button', { name: 'Cancel' }).click();
  await h.page.waitForTimeout(200);
  assert.equal(await cat('m2a.txt'), 'uno'); assert.equal(await cat('m2b.txt'), 'dos');
});

test('si un cambio no se puede preparar no se propone ninguno', async () => {
  const x = await setup('m3');
  const out = await h.run(proposal([
    { path: 'm3a.txt', hash: x.a, operation: 'replace', old: 'uno', new: 'X' },
    { path: 'm3b.txt', hash: x.b, operation: 'replace', old: 'NO EXISTE', new: 'Y' }]));
  assert.match(out, /❌ change 2 \(m3b\.txt\)/);
  assert.equal(await dialog().count(), 0);
  assert.equal(await cat('m3a.txt'), 'uno');
});

test('si un archivo cambia durante la revisión no se escribe ninguno', async () => {
  const x = await setup('m4');
  await h.run(proposal([
    { path: 'm4a.txt', hash: x.a, operation: 'replace', old: 'uno', new: 'X' },
    { path: 'm4b.txt', hash: x.b, operation: 'replace', old: 'dos', new: 'Y' }]));
  await h.page.evaluate(async () => {
    const root = await navigator.storage.getDirectory();
    const w = await (await root.getFileHandle('m4b.txt')).createWritable(); await w.write('cambiado fuera'); await w.close();
  });
  await dialog().getByRole('button', { name: 'Apply all' }).click();
  await h.page.waitForTimeout(600);
  assert.match(await h.page.evaluate(() => document.getElementById('dv-code-editor').shadowRoot.textContent), /changed since the review/);
  await dialog().getByRole('button', { name: 'Cancel' }).click();
  await h.page.waitForTimeout(200);
  assert.equal(await cat('m4a.txt'), 'uno');
});

test('valida el formato: duplicados, anidados, un solo cambio y campos extra', async () => {
  const hash = '0'.repeat(64);
  const c = { path: 'a.txt', hash, operation: 'append', new: 'x' };
  assert.match(await h.run(proposal([c, c])), /repeated path/);
  assert.match(await h.run(proposal([c])), /2 to 20/);
  assert.match(await h.run(`!propose '${JSON.stringify({ changes: [c, { ...c, path: 'b.txt' }], extra: 1 })}'`), /only accepts the changes field/);
});

test('sin errores de página', () => assert.deepEqual(h.errors, []));
