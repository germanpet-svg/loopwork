import test from 'node:test';
import assert from 'node:assert/strict';
import { launch } from '../harness.mjs';

let h;
test.before(async () => { h = await launch(); });
test.after(async () => { await h.close(); });

const hashOf = async (file) => (await h.run(`!view ${file}`)).match(/SHA256: ([0-9a-f]{64})/)[1];
const editorText = () => h.page.evaluate(() => document.getElementById('dv-code-editor')?.shadowRoot.querySelector('textarea')?.value ?? null);
const closeEditor = async () => {
  if (await h.page.locator('#dv-code-editor').count()) {
    await h.page.locator('#dv-code-editor').getByRole('button', { name: 'Close' }).first().click();
    await h.page.waitForTimeout(200);
  }
};

test('git log --oneline, -n y -- archivo; git diff entre dos commits', async () => {
  await h.run('!git init');
  await h.run('!write a.txt "uno"');
  await h.run('!write b.txt "otro"');
  await h.run('!git add a.txt'); await h.run('!git add b.txt');
  await h.run('!git commit -m "primero"');
  await h.run('!write a.txt "dos"');
  await h.run('!git add a.txt');
  await h.run('!git commit -m "segundo"');
  const oneline = (await h.run('!git log --oneline')).trim().split('\n').slice(-2);
  assert.match(oneline[0], /^[0-9a-f]{7} segundo$/);
  assert.match(oneline[1], /^[0-9a-f]{7} primero$/);
  assert.equal((await h.run('!git log --oneline -n 1')).trim().split('\n').filter((l) => /^[0-9a-f]{7} /.test(l)).length, 1);
  assert.doesNotMatch(await h.run('!git log -- b.txt'), /segundo/);
  const [second, first] = oneline.map((l) => l.slice(0, 7));
  const diff = await h.run(`!git diff ${first} ${second}`);
  assert.match(diff, /-uno/);
  assert.match(diff, /\+dos/);
  assert.doesNotMatch(diff, /b\.txt/);
  assert.match(await h.run(`!git diff ${first} ${first}`), /No differences/);
  assert.match(await h.run('!git diff zzzzzzz abc'), /❌/);
});

test('propose con operation patch aplica un diff unificado exacto', async () => {
  await h.run('!write p.txt "l1\nl2\nl3\n"');
  const hash = await hashOf('p.txt');
  const patch = '--- a/p.txt\\n+++ b/p.txt\\n@@ -1,3 +1,3 @@\\n l1\\n-l2\\n+L2\\n l3\\n';
  const out = await h.run(`!propose '{"path":"p.txt","hash":"${hash}","operation":"patch","patch":"${patch}"}'`);
  assert.match(out, /Proposal prepared/);
  assert.equal(await editorText(), 'l1\nL2\nl3\n');
  await closeEditor();
});

test('patch con contexto que no coincide se rechaza sin abrir el editor', async () => {
  const hash = await hashOf('p.txt');
  const patch = '--- a/p.txt\\n+++ b/p.txt\\n@@ -1,3 +1,3 @@\\n l1\\n-XX\\n+YY\\n l3\\n';
  const out = await h.run(`!propose '{"path":"p.txt","hash":"${hash}","operation":"patch","patch":"${patch}"}'`);
  assert.match(out, /❌.*does not apply/);
  assert.equal(await h.page.locator('#dv-code-editor').count(), 0);
});

test('patch exige hash vigente y no admite old/new', async () => {
  const stale = await h.run(`!propose '{"path":"p.txt","hash":"${'0'.repeat(64)}","operation":"patch","patch":"x"}'`);
  assert.match(stale, /❌/);
  const hash = await hashOf('p.txt');
  assert.match(await h.run(`!propose '{"path":"p.txt","hash":"${hash}","operation":"patch","patch":"x","old":"a"}'`), /❌.*old\/new/);
});

test('replace --regex: una coincidencia, --all, ambigua y vacía', async () => {
  await h.run('!write r.txt "v1 v2 v3"');
  assert.match(await h.run('!replace r.txt "v[0-9]" "V"  --regex'), /❌.*3 times/);
  assert.match(await h.run('!replace r.txt "v([0-9])" "V$1" --regex --all'), /3 replacement/);
  assert.equal(await editorText(), 'V1 V2 V3');
  await closeEditor();
  assert.match(await h.run('!replace r.txt "zzz" "x" --regex'), /❌.*does not match/);
  assert.match(await h.run('!replace r.txt "x*" "y" --regex --all'), /❌.*empty text/);
  assert.match(await h.run('!replace r.txt "(" "y" --regex'), /❌.*regular expression/);
});

test('el editor avisa de JSON no válido al revisar el diff', async () => {
  await h.run('!write c.json "{\\"a\\":1}"');
  await h.run('!replace c.json "1" "1,"');
  const ed = h.page.locator('#dv-code-editor');
  await ed.getByRole('button', { name: 'Review diff' }).click();
  await h.page.waitForTimeout(500);
  const text = await h.page.evaluate(() => document.getElementById('dv-code-editor').shadowRoot.textContent);
  assert.match(text, /Invalid JSON/);
  await closeEditor();
});

test('sin errores de página', () => assert.deepEqual(h.errors, []));
