// Arnés e2e: sirve una copia de loopwork.js con shadow DOM abierto (para poder inspeccionarlo)
// junto a las librerías @require, y ofrece ayudas para ejecutar comandos del panel.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..', '..');
const require = createRequire(import.meta.url);

function lib(pkg, rel, vendorName) {
  try { return fs.readFileSync(require.resolve(`${pkg}/${rel}`)); } catch { /* sin node_modules */ }
  const vendored = path.join(root, 'extension', 'vendor', vendorName);
  if (fs.existsSync(vendored)) return fs.readFileSync(vendored);
  throw new Error(`Falta ${pkg}: ejecuta "npm install" en tests/e2e o genera extension/ con tools/build-extension.py`);
}

export function buildSite(pageHtml, { extraFiles = {} } = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'loopwork-e2e-'));
  const src = fs.readFileSync(process.env.LOOPWORK_JS || path.join(root, 'loopwork.js'), 'utf8');
  if (!src.includes("attachShadow({ mode: 'closed' })")) throw new Error('No se encontró attachShadow closed para abrirlo en el arnés');
  fs.writeFileSync(path.join(dir, 'app.js'), src.replaceAll("attachShadow({ mode: 'closed' })", "attachShadow({ mode: 'open' })"));
  fs.writeFileSync(path.join(dir, 'isomorphic-git.umd.min.js'), lib('isomorphic-git', 'index.umd.min.js', 'isomorphic-git.umd.min.js'));
  fs.writeFileSync(path.join(dir, 'diff.min.js'), lib('diff', 'dist/diff.min.js', 'diff.min.js'));
  fs.writeFileSync(path.join(dir, 'index.html'), pageHtml ??
    '<!doctype html><meta charset="utf-8"><title>t</title><textarea id="c"></textarea>' +
    '<script src="isomorphic-git.umd.min.js"></script><script src="diff.min.js"></script><script src="app.js"></script>');
  for (const [name, body] of Object.entries(extraFiles)) fs.writeFileSync(path.join(dir, name), body);
  return dir;
}

export function serve(dir) {
  return new Promise((resolve) => {
    const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8' };
    const server = http.createServer((req, res) => {
      const file = path.join(dir, req.url === '/' ? 'index.html' : decodeURIComponent(req.url.split('?')[0]));
      if (!file.startsWith(dir) || !fs.existsSync(file)) { res.writeHead(404).end(); return; }
      res.writeHead(200, { 'content-type': types[path.extname(file)] || 'application/octet-stream' }).end(fs.readFileSync(file));
    });
    server.listen(0, '127.0.0.1', () => resolve({ server, url: `http://127.0.0.1:${server.address().port}/` }));
  });
}

// origin: p. ej. 'https://claude.ai/' sirve la página de prueba bajo ese host (para probar el adaptador de cada sitio).
export async function launch({ pageHtml, locale = 'en-US', origin = null } = {}) {
  const { chromium } = require('playwright');
  const dir = buildSite(pageHtml);
  const { server, url } = await serve(dir);
  const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined });
  const context = await browser.newContext({ viewport: { width: 1280, height: 800 }, locale });
  const page = await context.newPage();
  const errors = [];
  const dialogs = [];
  let dialogAnswer = true;
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('dialog', (d) => { dialogs.push(d.message()); (dialogAnswer ? d.accept() : d.dismiss()); });
  if (origin) {
    await context.route(`${origin}**`, (route) => {
      const name = new URL(route.request().url()).pathname.replace(/^\//, '') || 'index.html';
      const file = path.join(dir, name);
      if (!file.startsWith(dir) || !fs.existsSync(file)) return route.fulfill({ status: 404, body: '' });
      route.fulfill({ status: 200, contentType: name.endsWith('.js') ? 'text/javascript' : 'text/html; charset=utf-8', body: fs.readFileSync(file) });
    });
  }
  await page.goto(origin || url);
  await page.waitForSelector('#dv-host', { state: 'attached' });
  await page.waitForFunction(() => document.getElementById('dv-host')?.shadowRoot?.querySelector('.input-cmd'));
  const api = {
    page, errors, dialogs, url,
    answerDialogs(value) { dialogAnswer = value; },
    // Ejecuta un comando local y devuelve el texto que añadió al registro.
    async run(command) {
      const before = await page.evaluate(() => document.getElementById('dv-host').shadowRoot.querySelector('#log').innerText);
      const input = page.locator('#dv-host').locator('.input-cmd');
      await input.fill(command);
      await input.press('Enter');
      await page.waitForTimeout(50);
      let after = before;
      for (let i = 0; i < 80; i++) {
        await page.waitForTimeout(100);
        after = await page.evaluate(() => document.getElementById('dv-host').shadowRoot.querySelector('#log').innerText);
        if (after !== before) { await page.waitForTimeout(250); after = await page.evaluate(() => document.getElementById('dv-host').shadowRoot.querySelector('#log').innerText); break; }
      }
      return after.startsWith(before) ? after.slice(before.length) : after;
    },
    async close() { await browser.close(); server.close(); fs.rmSync(dir, { recursive: true, force: true }); }
  };
  return api;
}
