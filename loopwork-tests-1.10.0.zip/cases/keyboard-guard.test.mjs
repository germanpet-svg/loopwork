import test from 'node:test';
import assert from 'node:assert/strict';
import { launch } from '../harness.mjs';

// Sitio hostil estilo ChatGPT: al teclear con el foco fuera de un campo editable, lleva el texto al composer.
// loopwork se carga primero (como con @run-at document-start); el manejador del sitio se registra después.
const PAGE = `<!doctype html><meta charset="utf-8"><title>ChatGPT (test)</title><head>
<script src="isomorphic-git.umd.min.js"></script><script src="diff.min.js"></script><script src="app.js"></script>
<script>
  window.__siteKeys = 0;
  const editable = (el) => el && (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT' || el.isContentEditable);
  window.addEventListener('keydown', (e) => {
    window.__siteKeys++;
    if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !editable(document.activeElement)) {
      const box = document.getElementById('prompt-textarea'); box.focus();
    }
  }, true);
</script></head>
<body><div id="prompt-textarea" contenteditable="true"></div></body>`;

let h;
test.before(async () => { h = await launch({ pageHtml: PAGE }); });
test.after(async () => { await h.close(); });

const inPanel = () => h.page.evaluate(() => document.getElementById('dv-host').shadowRoot.querySelector('.input-cmd').value);
const composer = () => h.page.evaluate(() => document.getElementById('prompt-textarea').textContent);

test('lo que escribes en el panel se queda en el panel y el sitio no ve las teclas', async () => {
  await h.page.evaluate(() => document.getElementById('dv-host').shadowRoot.querySelector('.input-cmd').focus());
  await h.page.keyboard.type('!ls -R');
  assert.equal(await inPanel(), '!ls -R');
  assert.equal(await composer(), '');
  assert.equal(await h.page.evaluate(() => window.__siteKeys), 0);
});

test('Enter ejecuta el comando y las flechas recorren el historial (el panel sigue recibiendo las teclas)', async () => {
  await h.page.keyboard.press('Enter');
  await h.page.waitForTimeout(600);
  assert.equal(await inPanel(), '');
  await h.page.keyboard.press('ArrowUp');
  assert.equal(await inPanel(), 'ls -R');
  assert.equal(await composer(), '');
});

test('Shift+Enter añade una línea y no ejecuta', async () => {
  await h.page.keyboard.press('Control+End');
  await h.page.keyboard.press('Shift+Enter');
  assert.equal(await inPanel(), 'ls -R\n');
});

test('fuera del panel el sitio sigue recibiendo sus teclas', async () => {
  await h.page.evaluate(() => document.activeElement.blur());
  await h.page.keyboard.type('a');
  assert.ok(await h.page.evaluate(() => window.__siteKeys) > 0);
});

test('el editor también está aislado: escribir en él no llega al composer', async () => {
  await h.page.evaluate(() => document.getElementById('dv-host').shadowRoot.querySelector('.input-cmd').value = '');
  await h.page.evaluate(() => { window.__siteKeys = 0; document.getElementById('prompt-textarea').textContent = ''; });
  await h.page.evaluate(() => document.getElementById('dv-host').shadowRoot.querySelector('.input-cmd').focus());
  await h.page.keyboard.type('!edit k.txt');
  await h.page.keyboard.press('Enter');
  await h.page.waitForSelector('#dv-code-editor', { state: 'attached' });
  await h.page.waitForTimeout(400);
  await h.page.evaluate(() => document.getElementById('dv-code-editor').shadowRoot.querySelector('textarea').focus());
  await h.page.keyboard.type('hola mundo');
  assert.equal(await h.page.evaluate(() => document.getElementById('dv-code-editor').shadowRoot.querySelector('textarea').value), 'hola mundo');
  assert.equal(await composer(), '');
});

test('sin errores de página', () => assert.deepEqual(h.errors, []));
