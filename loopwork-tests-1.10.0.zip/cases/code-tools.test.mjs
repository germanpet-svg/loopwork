import test from 'node:test';
import assert from 'node:assert/strict';
import { launch } from '../harness.mjs';

let h;
test.before(async () => { h = await launch(); });
test.after(async () => { await h.close(); });

const ed = () => h.page.locator('#dv-code-editor');
const text = () => ed().locator('textarea.code').inputValue();
const hashOf = async (file) => (await h.run(`!view ${file}`)).match(/SHA256: ([0-9a-f]{64})/)[1];
const cat = async (file) => (await h.run(`!cat ${file}`)).split('\n').slice(2).join('\n');
async function closeEditor() {
  await ed().getByRole('button', { name: 'Close', exact: true }).first().click();
  await h.page.waitForTimeout(200);
}

test('Revisar cuenta los problemas de un CSS y Arreglar todo añade los ;', async () => {
  await h.run('!write s.css "a {\n  color: red\n  margin: 0\n}\n"');
  await h.run('!edit s.css');
  await h.page.waitForTimeout(500);
  await expectCheckLabel('Check ⚠ 2');
  await ed().locator('button', { hasText: /^Check/ }).click();
  await ed().getByRole('button', { name: 'Fix all' }).click();
  assert.equal(await text(), 'a {\n  color: red;\n  margin: 0;\n}\n');
  await expectCheckLabel('Check ✓');
  await closeEditor();
});

async function expectCheckLabel(label) {
  for (let i = 0; i < 30; i++) {
    if ((await ed().locator('button', { hasText: /^Check/ }).first().textContent()).trim() === label) return;
    await h.page.waitForTimeout(100);
  }
  assert.equal((await ed().locator('button', { hasText: /^Check/ }).first().textContent()).trim(), label);
}

test('un JS con llave sin cerrar se detecta y se arregla desde la lista', async () => {
  await h.run('!write b.js "function a() {\n  return 1;\n"');
  await h.run('!edit b.js');
  await expectCheckLabel('Check ⚠ 1');
  await ed().locator('button', { hasText: /^Check/ }).click();
  await ed().locator('.prow').getByRole('button', { name: 'Fix', exact: true }).click();
  assert.equal(await text(), 'function a() {\n  return 1;\n\n}');
  await closeEditor();
});

const JS = 'function one() {\n  return 1;\n}\n\nfunction two() {\n  return 2;\n}\n';

test('el botón Función selecciona la función del cursor y repetir sube de nivel', async () => {
  await h.run(`!write f.js "${JS}"`);
  await h.run('!edit f.js');
  const at = JS.indexOf('return 2');
  await h.page.evaluate((pos) => {
    const ta = document.getElementById('dv-code-editor').shadowRoot.querySelector('textarea.code');
    ta.focus(); ta.setSelectionRange(pos, pos);
  }, at);
  await ed().locator('button', { hasText: /^Function$/ }).click();
  const sel = () => h.page.evaluate(() => {
    const ta = document.getElementById('dv-code-editor').shadowRoot.querySelector('textarea.code');
    return ta.value.slice(ta.selectionStart, ta.selectionEnd);
  });
  assert.equal(await sel(), 'function two() {\n  return 2;\n}');
  await closeEditor();
});

test('Reemplazar función pega el portapapeles sobre la función del cursor', async () => {
  await h.page.context().grantPermissions(['clipboard-read', 'clipboard-write']);
  await h.page.evaluate(() => navigator.clipboard.writeText('function two() {\n  return 22;\n}\n'));
  await h.run('!edit f.js');
  const at = JS.indexOf('return 2');
  await h.page.evaluate((pos) => {
    const ta = document.getElementById('dv-code-editor').shadowRoot.querySelector('textarea.code');
    ta.focus(); ta.setSelectionRange(pos, pos);
  }, at);
  await ed().locator('button', { hasText: /^Replace function$/ }).click();
  await h.page.waitForTimeout(200);
  assert.equal(await text(), 'function one() {\n  return 1;\n}\n\nfunction two() {\n  return 22;\n}\n');
  await closeEditor();
  h.answerDialogs(true);
});

test('propose replace-function abre el editor con la función cambiada y se aplica', async () => {
  const hash = await hashOf('f.js');
  const json = JSON.stringify({ path: 'f.js', hash, operation: 'replace-function', name: 'one', new: 'function one() {\n  return 11;\n}' });
  const out = await h.run(`!propose '${json}'`);
  assert.match(out, /prepared/i);
  await ed().getByRole('button', { name: /Apply changes/ }).first().click();
  await h.page.waitForTimeout(800);
  assert.match(await cat('f.js'), /return 11;[\s\S]*return 2;/);
});

test('replace-function rechaza nombres que no existen, ambiguos y funciones cortadas', async () => {
  const hash = await hashOf('f.js');
  const base = { path: 'f.js', hash, operation: 'replace-function' };
  const run = (extra) => h.run(`!propose '${JSON.stringify({ ...base, ...extra })}'`);
  assert.match(await run({ name: 'nada', new: 'function nada() {}' }), /❌ function nada not found; available: one, two/);
  assert.match(await run({ name: 'one', new: 'function one() {\n  return 3;' }), /❌ the new function has unbalanced/);
  assert.match(await run({ name: 'one', new: 'x', old: 'y' }), /❌ replace-function does not accept old/);
  assert.match(await run({ name: 'bad name', new: 'function x() {}' }), /❌ name must be a function name/);
  await h.run('!write dup.js "class A {\n  go() { return 1; }\n}\nclass B {\n  go() { return 2; }\n}\n"');
  const dh = await hashOf('dup.js');
  const amb = await h.run(`!propose '${JSON.stringify({ path: 'dup.js', hash: dh, operation: 'replace-function', name: 'go', new: 'go() { return 3; }' })}'`);
  assert.match(amb, /❌ name go is ambiguous \(lines 2, 5\)/);
  assert.equal(await ed().count(), 0);
});

test('replace-function en un archivo de texto no está permitido', async () => {
  await h.run('!write n.txt "hola"');
  const hash = await hashOf('n.txt');
  const out = await h.run(`!propose '${JSON.stringify({ path: 'n.txt', hash, operation: 'replace-function', name: 'a', new: 'function a() {}' })}'`);
  assert.match(out, /❌ replace-function is only available for JavaScript, Python/);
});

test('las guías de bloque aparecen junto a los números de línea, se resaltan con el cursor y se pueden ocultar', async () => {
  const src = 'function a() {\n  if (x) {\n    y();\n  }\n}\n';
  await h.run(`!write g.js "${src}"`);
  await h.run('!edit g.js');
  await h.page.waitForTimeout(400);
  const info = () => h.page.evaluate(() => {
    const r = document.getElementById('dv-code-editor').shadowRoot;
    const g = r.querySelector('.guides');
    return { shown: g.style.display !== 'none', n: g.querySelectorAll('.g').length, on: [...g.querySelectorAll('.g')].map((x) => x.classList.contains('on')) };
  });
  assert.deepEqual(await info(), { shown: true, n: 2, on: [true, false] });
  const at = src.indexOf('y();');
  await h.page.evaluate((p) => {
    const ta = document.getElementById('dv-code-editor').shadowRoot.querySelector('textarea.code');
    ta.focus(); ta.setSelectionRange(p, p); ta.dispatchEvent(new Event('click'));
  }, at);
  assert.deepEqual((await info()).on, [false, true]);
  await h.page.evaluate(() => document.getElementById('dv-code-editor').shadowRoot.querySelector('.g').click());
  const sel = await h.page.evaluate(() => {
    const ta = document.getElementById('dv-code-editor').shadowRoot.querySelector('textarea.code');
    return ta.value.slice(ta.selectionStart, ta.selectionEnd);
  });
  assert.equal(sel, src.trimEnd());
  await ed().locator('button', { hasText: /^Guides$/ }).click();
  assert.equal((await info()).shown, false);
  await ed().locator('button', { hasText: /^Guides$/ }).click();
  assert.equal((await info()).shown, true);
  await closeEditor();
});
