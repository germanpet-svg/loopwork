// Mundo aislado: recibe el clic del icono de la barra (service worker) y avisa a loopwork, que vive en el
// mundo MAIN, con un evento DOM. No lee ni escribe nada de la página.
chrome.runtime.onMessage.addListener(function (msg) {
  if (msg && msg.type === 'loopwork:toggle') window.dispatchEvent(new CustomEvent('loopwork:toggle'));
});
