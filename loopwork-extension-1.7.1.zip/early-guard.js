// loopwork: se ejecuta antes que los scripts del sitio (document_start, mundo MAIN).
// Registra, en la fase de captura de window, un aislamiento de copiar/cortar/pegar para el
// panel y el editor de loopwork. Así los manejadores globales del sitio (claude.ai desvía el
// pegado a su propio composer cuando el foco no está en un campo editable) no ven el evento
// y el navegador pega en el campo del panel. No cancela el evento: la acción nativa sigue.
(function () {
  var IDS = { 'dv-host': true, 'dv-code-editor': true };
  function isOurs(e) {
    var path = e.composedPath ? e.composedPath() : [];
    for (var i = 0; i < path.length; i++) {
      if (path[i] && IDS[path[i].id]) return true;
    }
    return false;
  }
  ['paste', 'copy', 'cut'].forEach(function (type) {
    window.addEventListener(type, function (e) {
      if (e.defaultPrevented || !isOurs(e)) return;
      e.stopImmediatePropagation();
    }, true);
  });
})();
