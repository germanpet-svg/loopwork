// Clic en el icono de la barra: mostrar/ocultar el panel de la pestaña. No requiere permisos.
chrome.action.onClicked.addListener(function (tab) {
  if (!tab || tab.id == null) return;
  chrome.tabs.sendMessage(tab.id, { type: 'loopwork:toggle' }).catch(function () {
    // Pestaña sin loopwork (otra web o sin recargar): no hay nada que mostrar.
  });
});
